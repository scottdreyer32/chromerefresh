document.addEventListener("readystatechange", function(){
	if(document.readyState == "complete"){
		var bbuy = document.querySelectorAll(".add-to-cart-button");
		var ob = {
				message: "BESTBUY",
				fileName: 'BESTBUY.txt',
				data: "Out of Stock",
				link: "",
			}
		if(bbuy.length > 0)
		{
			var i;
			for (i = 0; i < bbuy.length; i++) {
			  if(!bbuy[i].classList.contains("btn-disabled"))
			  {
				  ob.data = "Check BestBuy: " + document.URL;
			  }
			}
		}
		chrome.runtime.sendMessage(ob, function(response) {
		});
	}
});