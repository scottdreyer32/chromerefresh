document.addEventListener('DOMContentLoaded', function () {
	var button = document.getElementById("startButtonNoInt")
	button.addEventListener("click", (e) => {
		refreshIt();
	});
	var button2 = document.getElementById("stopButtonNoInt")
	button2.addEventListener("click", (e) => {
		stopRefreshing();
	})
  	var button3 = document.getElementById("clearStorage")
	button3.addEventListener("click", (e) => {
		clearStorage();
	})
});
function clearStorage(){
	chrome.storage.local.clear();
}
function refreshIt(){
	chrome.tabs.query({active: true,currentWindow: true}, function(tabs){
        var tabId = tabs[0].id;
		//var url = tabs[0].url;
		//setTabSiteKey(tabId,url);
		var tabsetting = tabId + "_AutoRefresh";
		chrome.storage.local.set({[tabsetting]: true}, function() {
		});
		var inp = document.getElementById("numSecondsToRefresh").value;
		if(inp == "")
			inp = "30";
		var interval = inp * 1000;
		if(interval < 5000)
			interval = 5000;
		winViews = chrome.extension.getViews();
		winViews[0].refreshTab(tabId,interval,tabsetting);
	});
}
function stopRefreshing(){
	chrome.tabs.query({active: true,currentWindow: true}, function(tabs){
		var tabId = tabs[0].id;
		var tabsetting = tabId + "_AutoRefresh";
		winViews = chrome.extension.getViews();
		winViews[0].removeTabFromProcess(tabsetting);
	});
}
function setTabSiteKey(tabId,url){
	var site = "";
	if(url.includes('bestbuy')){
		site = "BESTBUY";
	}else if(url.includes('walmart')){
		site = "WALMART";
	}else if(url.includes('target')){
		site = "TARGET";
	}else if(url.includes('playstation')){
		site = "PSN";
	}
	chrome.storage.local.set({[site]: tabId}, function() {
	});
}
