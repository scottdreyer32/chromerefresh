document.addEventListener("readystatechange", function(){
	if(document.readyState == "complete"){
		var ob = {
				message: "NEWEGG",
				fileName: 'NEWEGG.txt',
				data: "Out of Stock",
				link: "",
			}
		var tax = document.querySelectorAll(".btn,.btn-mini")
		if(tax.length > 0)
		{
			ob.data = "Out of Stock";
			var i;
			for (i = 0; i < tax.length; i++) {
			  if(tax[i].textContent.indexOf("Add to") != -1)
			  {
				  ob.data = "Check Newegg: " + document.URL;
			  }
			}
		}
		chrome.runtime.sendMessage(ob, function(response) {
		});	
	}
});