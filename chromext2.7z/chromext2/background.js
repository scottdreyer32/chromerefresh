chrome.runtime.onMessage.addListener(
  function(request, sender, sendResponse) {
	  var settingId = request.message;
	  chrome.storage.local.get(settingId, function(result) {
			if(result[settingId] == request.data)
			{
			}
			else{
				//if(request.data == "CHECK NOW"){
				//	removeTabFromProcessBySite(request.message);
				//}
				setStorage(settingId,request.data);
				makeFile(request);
			}
		});
		var resp = settingId + "handled";
		sendResponse({response: resp});
  }
);
function makeFile(fData){
	var file = new Blob([fData.data], {type: "text/plain"});
	if (window.navigator.msSaveOrOpenBlob) // IE10+
		window.navigator.msSaveOrOpenBlob(file, fData.fileName);
	else { // Others
		var a = document.createElement("a"),
		url = URL.createObjectURL(file);
		a.href = url;
		a.download = fData.fileName;
		document.body.appendChild(a);
		a.click();
		document.body.removeChild(a);
		window.URL.revokeObjectURL(url);
	}
}
function refreshTab(tabId,interval,settingId){
	setInterval(function () {
		chrome.storage.local.get(settingId, function(result) {
			if(result[settingId] == true)
			{
				chrome.tabs.get(tabId, function(tab) {
					if (typeof tab == 'undefined') {
						var tabsetting = tabId + '_AutoRefresh';
						removeTabFromProcess(tabsetting);
					}else{
						chrome.tabs.executeScript(tabId,{
							code: 'window.location.reload();'
						});
					}
				});

			}
		});
	}, interval);
}
function removeTabFromProcess(tabSetting){
	setStorage(tabSetting,false);
}
function removeTabFromProcessBySite(site){
	chrome.storage.local.get(site, function(result) {
		var sett = result[site] + '_AutoRefresh';
		setStorage(sett,false);
	});
}
function setStorage(tabSetting,value){
	chrome.storage.local.set({[tabSetting]: value}, function() {
	});
}
function reloadWindow(tabId){
	chrome.tabs.executeScript(tabId,{
		code: 'window.location.reload();'
	});
}